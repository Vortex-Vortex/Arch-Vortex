#!/bin/bash

main() {
    file=$(echo "$1" | sed "s|\.|$PWD|")

    echo "Processing file: $file"

    file_name=$(basename "$file")
    file_path=$(dirname "$file")

    input_pdf=$file

    temp_dir=$(mktemp -d)
    echo "Processing at: $temp_dir"
    cp "$input_pdf" "$temp_dir/input.pdf"

    cd "$temp_dir"
    pdftk input.pdf burst output output-%d.pdf
    ls
    array=()
    padded=''
    i=0
    for page in ./output-*pdf; do
        i=$((i + 1))
        printf -v padded "%02d" $i
        dimensions=$(pdfinfo "$page" | grep "Page size:" | awk '{print $3,$5}' | sed 's/ /x/')
        convert xc:none -page $dimensions blank.pdf
        pdfjam "$page" blank.pdf --nup 2x1 --landscape --outfile "$temp_dir/merged-$padded.pdf"

        array+=("$temp_dir/merged-$padded.pdf")
    done &> /dev/null

    pdftk ${array[@]} cat output "finished.pdf"
    cd -
    cp "$temp_dir/finished.pdf" "${file_path}/mod_${file_name}"

    rm -rdf "$temp_dir"
    echo "Finished Processing file: $file"
}

find_results=$(find ./ -type f | grep .pdf)

while IFS= read -r line; do
    if [[ $(jobs -r -p | wc -l) -ge 8 ]]; then
        wait -n
    fi
    main "$line" &
#     break
done <<< "$find_results"

