#!/bin/bash

temp_dir=$(mktemp -d)
cd $temp_dir

timeframes=(1 5 10 15 30 60 120 240 480)

for file in /home/vortex/Downloads/SPXUSD_min/DAT*; do
    for timeframe in ${timeframes[@]}; do
        python /home/vortex/Documents/Projects/miscelaneous/candle_convert.py "$file" $timeframe

        case $timeframe in
            1|5|10|15|30)
                real_timeframe=${timeframe}m
                ;;
            60)
                real_timeframe=1H
                ;;
            120)
                real_timeframe=2H
                ;;
            240)
                real_timeframe=4H
                ;;
            480)
                real_timeframe=8H
                ;;
            *)
                exit
        esac
        mkdir /home/vortex/Documents/Projects/miscelaneous/spx_data/$real_timeframe &> /dev/null
        mv *.csv /home/vortex/Documents/Projects/miscelaneous/spx_data/$real_timeframe/
    done
done

rm -rd $temp_dir
