#!/bin/bash

'''
This script creates images os days approx fed meetings/decisions

I forgot how to feed it data files
'''

date_to_unix() {
    formatted_date=$(sed 's/\([0-9]\{2\}\)\/\([0-9]\{2\}\)\/\([0-9]\{4\}\)/\3\/\2\/\1/' <<< "$1")
    echo "$(date -u -d "$formatted_date" +"%s")"
}

unix_to_date() {
    formatted_date=$(sed 's/\([0-9]\{2\}\)\/\([0-9]\{2\}\)\/\([0-9]\{4\}\)/\3\/\2\/\1/' <<< "$1")
    date -u -d @"$formatted_date" "+%d/%m/%Y"
}

change_date() { # feed unix_date to it + number of days
    local -r days=$2
    local -r unix_date=$1

    unix_change=$(( days * 86400 ))
    date_change=$(( unix_date + unix_change ))
    target_date=$(unix_to_date $date_change)
    echo $target_date
}

bitcoin_data="$1"
dates_data="$2"

i=0
while read line; do
    ((i++))
    printf -v i_zero "%02d" $i
    date=$(sed 's/\s.*//' <<< $line)
    interest=$(sed 's/.*\s//' <<< $line)
    unix_date=$(date_to_unix $date)
    prev_date=$(change_date $unix_date '-1')
    next_date=$(change_date $unix_date '1')
    next_next_date=$(change_date $unix_date '2')

    while read line; do
        start=$(sed 's/\s.*//' <<< "$line")
        end=$(sed 's/.*\s//' <<< "$line")
        [[ $unix_date -gt $start && $unix_date -lt $end ]] && fomc_time="18:00" && break || fomc_time="19:00"
    done < /tmp/dst.tmp

    echo $fomc_time
    cat $bitcoin_data | grep -iE "$date|$prev_date|$next_date|$next_next_date" | \
            cut -d ',' -f 2-6 | \
            sed 's/\([0-9]\{2\}\)\/\([0-9]\{2\}\)\/\([0-9]\{4\}\)/\3-\2-\1/' | \
            sed 's/,/ /g' | \
            sed 's/\([0-9]\{2\}:[0-9]\{2\}\):[0-9]\{2\}/\1/' \
            > /tmp/bitcoin.tmp

    btc_open=$(cat /tmp/bitcoin.tmp | grep $fomc_time | sed -n '2p' | cut -d ' ' -f 3)
    btc_high=$(cat /tmp/bitcoin.tmp | grep $fomc_time | sed -n '2p' | cut -d ' ' -f 4)
    btc_low=$(cat /tmp/bitcoin.tmp | grep $fomc_time | sed -n '2p' | cut -d ' ' -f 5)
    btc_prev_open=$(cat /tmp/bitcoin.tmp | grep $fomc_time | sed -n '1p' | cut -d ' ' -f 3)
    echo "date: $date"
    echo "btc_open: $btc_open"
    echo "btc_high: $btc_high"
    echo "btc_low: $btc_low"
    echo "btc_prev_open: $btc_prev_open"

    open_high_change=$(echo "scale=4; (($btc_high/$btc_open)-1)*100" | bc -l)
    open_low_change=$(echo "scale=4; (($btc_low/$btc_open)-1)*100" | bc -l)
    day_change=$(echo "scale=4; (($btc_open/$btc_prev_open)-1)*100" | bc -l)

    echo "close_high: $open_high_change"
    echo "close_low: $open_low_change"
    echo "day: $day_change"
    gnuplot_bar=$(echo "$date $fomc_time" | sed "s|\([0-9]\{2\}\)/\([0-9]\{2\}\)/\([0-9]\{4\}\)|\3/\2/\1|" | sed 's|/|-|g')
    sed -i "s|\(set arrow from\).*\(, graph 0 to\).*\(, graph 1.*\)|\1 \"${gnuplot_bar}\"\2 \"${gnuplot_bar}\"\3|" "$HOME/Scripts/gnuplot_script"
    gnuplot "$HOME/Scripts/gnuplot_script" -p
    [[ ! $interest == "na" ]] && cur_interest=$(sed 's/[\+\-].*//' <<< "$interest") && change_interest=$(sed 's/.*\([\+\-].*\)/\1/' <<< $interest) || \
    change_interest="+0.00"
    convert plot.png -fill black -draw "rectangle 0,0,825,65" -fill white -pointsize 21 -gravity northwest -annotate +10+10 "Current Interest rate: $cur_interest\nInterest rate change: $change_interest" plot.png
    convert plot.png -pointsize 21 -fill white -gravity northwest -annotate +290+10 "open to high: $open_high_change\nopen to low: $open_low_change" plot.png
    convert plot.png -pointsize 21 -fill white -gravity northwest -annotate +505+10 "prev_day to FOMC: $day_change" plot.png

    mv "plot.png" "./log/${i_zero}plot-[${date//\//-}].png"
#     exit
done < "$dates_data"


